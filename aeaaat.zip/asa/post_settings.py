from telegram import (
    Update,
    InlineKeyboardButton,
    InlineKeyboardMarkup
)

from telegram.constants import (
    ParseMode
)

from telegram.ext import (
    ContextTypes,
    ConversationHandler
)

true_false_dict = {True : 'نعم☑️',
                   False: 'لا❌'}

def build_yes_no_inline_keyboard():
    yes_no_inline_keyboard = [[InlineKeyboardButton(text='نعم☑️', callback_data='yes'), InlineKeyboardButton(text='لا❌', callback_data='no')]]

    return InlineKeyboardMarkup(yes_no_inline_keyboard)

def build_post_inline_keyboard():
    post_inline_keyboard = [[InlineKeyboardButton(text='فيسبوك🟦', callback_data='facebook post'), InlineKeyboardButton(text='انستغرام🟥', callback_data='instagram post')],
                            [InlineKeyboardButton(text='X(تويتر)⬛️', callback_data='twitter post'), InlineKeyboardButton(text='قناة تيليجرام⬜️', callback_data='telegram channel post')],
                            [InlineKeyboardButton(text="اعرض المنصات التي اخترتها👀", callback_data='show chosen')],
                            [InlineKeyboardButton(text='تم!🆗', callback_data='done')]]

    return InlineKeyboardMarkup(post_inline_keyboard)


def create_back_from_show_chosen_button():
    return InlineKeyboardMarkup([[InlineKeyboardButton(text="الرجوع🔙", callback_data="back from show chosen")]])


async def choose_platforms(update:Update, context:ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id in (5652465292, ):
        post_inline_keyboard = build_post_inline_keyboard()
        await update.message.reply_text(text="اختر المنصات التي تريد أن تنشر عليها، عند الانتهاء اضغط على <i>تم</i>.",
                                        parse_mode=ParseMode.HTML,
                                        reply_markup=post_inline_keyboard)
        return 1
    else:
        return ConversationHandler.END



async def on_done(update:Update, context:ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()

    yes_no_inline_keyboard = build_yes_no_inline_keyboard()
    await update.callback_query.edit_message_text(text=f"""سيتم النشر على المنصات:
فيسبوك🟦: {true_false_dict[context.bot_data['platforms']['facebook']]}
انستغرام🟥: {true_false_dict[context.bot_data['platforms']['instagram']]}
X(تويتر)⬛️: {true_false_dict[context.bot_data['platforms']['twitter']]}
قناة تيليجرام⬜️: {true_false_dict[context.bot_data['platforms']['telegram']]}

هل أنت متأكد أنك قد انتهيت؟""", reply_markup=yes_no_inline_keyboard)
    
    return 2


async def on_yes_done(update:Update, context:ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer("Updated successfully!")
    await update.callback_query.delete_message()
    return ConversationHandler.END


async def on_no_done(update:Update, context:ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    post_inline_keyboard = build_post_inline_keyboard()
    await update.message.reply_text(text="اختر المنصات التي تريد أن تنشر عليها، عند الانتهاء اضغط على <i>تم</i>.",
                                    parse_mode=ParseMode.HTML,
                                    reply_markup=post_inline_keyboard)
    return 1


async def on_show_chosen(update:Update, context:ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()

    back_button = create_back_from_show_chosen_button()
    await update.callback_query.edit_message_text(text=f"""سيتم النشر على المنصات:
فيسبوك🟦: {true_false_dict[context.bot_data['platforms']['facebook']]}
انستغرام🟥: {true_false_dict[context.bot_data['platforms']['instagram']]}
X(تويتر)⬛️: {true_false_dict[context.bot_data['platforms']['twitter']]}
قناة تيليجرام⬜️: {true_false_dict[context.bot_data['platforms']['telegram']]}""", reply_markup=back_button)
    

async def on_back_from_chosen(update:Update, context:ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()

    post_inline_keyboard = build_post_inline_keyboard()
    await update.callback_query.edit_message_text(text="اختر المنصات التي تريد أن تنشر عليها، عند الانتهاء اضغط على <i>تم</i>.",
                                                  parse_mode=ParseMode.HTML,
                                                  reply_markup=post_inline_keyboard)
    
    return 1