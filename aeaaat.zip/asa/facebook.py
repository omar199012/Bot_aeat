from telegram import (
    Update,
)
from telegram.ext import (
    ContextTypes,
)

import requests
from dotenv import load_dotenv
import os

async def facebook_post(update:Update, context:ContextTypes.DEFAULT_TYPE):
    if not context.bot_data['platforms']['facebook']:
        context.bot_data['platforms']['facebook'] = True
        await update.callback_query.answer(text='Facebook selected!', show_alert=True)
    else:
        context.bot_data['platforms']['facebook'] = False
        await update.callback_query.answer(text='Facebook cancelled!', show_alert=True)


async def post_on_facebook(text:str, context:ContextTypes.DEFAULT_TYPE):
    load_dotenv()
    fb_access_token = os.getenv("FACEBOOK_PAGE_ID")
    url = f"https://graph.facebook.com/{fb_access_token}/feed"

    params = {
        "access_token": os.getenv("FACEBOOK_ACCESS_TOKEN"),
        "message": text
    }

    response = requests.post(url, data=params)

    print("Posted on Facebook.")
    
    