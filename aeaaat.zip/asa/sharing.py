from telegram import (
    Update,
)
from telegram.ext import (
    ContextTypes
)

async def on_share_here(update:Update, context:ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer(text="قريباً!", show_alert=True)

async def on_share_somewhere_else(update:Update, context:ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer(text="قريباً!", show_alert=True)