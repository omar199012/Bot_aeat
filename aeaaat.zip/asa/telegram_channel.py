from telegram import (
    Update,
    InlineKeyboardButton,
    InlineKeyboardMarkup

)
from telegram.ext import (
    ContextTypes,
)

from telegram.constants import (
    ParseMode
)

from dotenv import load_dotenv
import os

def build_sharing_inline_keybord():
    sharing_inline_keybord = [[InlineKeyboardButton(text="شارك هنا!", callback_data="shre here"), InlineKeyboardButton(text="شارك في تطبيقات أخرى!", callback_data="share somewhere else")]]
    return InlineKeyboardMarkup(sharing_inline_keybord)

async def telegram_post(update:Update, context:ContextTypes.DEFAULT_TYPE):
    if not context.bot_data['platforms']['telegram']:
        context.bot_data['platforms']['telegram'] = True
        await update.callback_query.answer(text='Telegram Channel selected!', show_alert=True)
    else:
        context.bot_data['platforms']['telegram'] = False
        await update.callback_query.answer(text='Telegram Channel cancelled!', show_alert=True)


async def post_on_telegram(text:str, context:ContextTypes.DEFAULT_TYPE):
    load_dotenv()
    sharing_inline_keybord = build_sharing_inline_keybord()
    text = '<b>' + text + '</b>'
    await context.bot.send_message(chat_id=os.getenv("TELEGRAM_CHANNEL_ID"),
                                   text=text,
                                   parse_mode=ParseMode.HTML,
                                   reply_markup=sharing_inline_keybord)
    print("Posted on Telegram!")