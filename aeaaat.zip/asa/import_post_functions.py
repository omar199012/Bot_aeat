from facebook import post_on_facebook
from instagram import post_on_instagram
from twitter import post_on_twitter
from telegram_channel import post_on_telegram