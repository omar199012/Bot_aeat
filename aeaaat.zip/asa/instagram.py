from telegram import (
    Update,

)
from telegram.ext import (
    ContextTypes,
)

async def instagram_post(update:Update, context:ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer(text="Posting on Instagram is unavailable right now!", show_alert=True)
    
    # if not context.bot_data['platforms']['instagram']:
    #     context.bot_data['platforms']['instagram'] = True
    #     await update.callback_query.answer(text='Instagram selected!', show_alert=True)
    # else:
    #     context.bot_data['platforms']['instagram'] = False
    #     await update.callback_query.answer(text='Instagram cancelled!', show_alert=True)


async def post_on_instagram(text:str):
    pass